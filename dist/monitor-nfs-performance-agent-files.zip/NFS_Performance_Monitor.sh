#!/bin/bash
/usr/bin/nfsstat